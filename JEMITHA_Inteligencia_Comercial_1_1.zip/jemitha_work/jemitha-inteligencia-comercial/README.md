# JEMITHA Inteligencia Comercial 1.1

Aplicación web progresiva (PWA) para organizar prospectos y preparar el centro de trabajo de los agentes digitales JEMITHA.

## Novedad crítica: autorización de precios
- El catálogo inicia vacío: no se precargan precios ni paquetes inventados.
- Todo paquete nuevo queda **Pendiente**.
- Solo el propietario puede autorizarlo desde **Precios autorizados**.
- Para autorizar se exige un importe numérico válido.
- Editar nombre, descripción o importe incrementa la versión y revoca la aprobación anterior.
- Un precio retirado vuelve a quedar pendiente y deja de estar autorizado.
- No hay ninguna función que publique o envíe precios a clientes desde esta versión.
- Los agentes solo deben consultar registros con estado `approved`; si no existe precio aprobado, deben escalar la consulta al propietario.

## Ejecutar el prototipo
1. Descomprime el ZIP.
2. Sirve la carpeta mediante HTTPS o localhost (por ejemplo, `python -m http.server 8080`).
3. Abre `http://localhost:8080`.
4. Entra a **Precios autorizados** para crear paquetes y aprobar precios.

Los datos de esta versión se guardan en `localStorage` del navegador. No son multiusuario ni están protegidos como un sistema de producción. No uses esta versión local como único control de autorización en un negocio real.

## Archivos
- `index.html`, `styles.css`, `app.js`: interfaz y lógica local.
- `manifest.webmanifest`, `sw.js`: soporte PWA.
- `database/schema.sql`: esquema inicial PostgreSQL/Supabase con catálogo, RLS y función de aprobación.

## Antes de publicar y atender clientes reales
Esta entrega NO afirma tener conexión real con WhatsApp, Instagram, correo, IA, agenda, Supabase ni autenticación. Para producción deben completarse y probarse:
1. Proyecto Supabase dedicado, Auth y migración SQL.
2. Políticas RLS completas para todas las tablas y pruebas negativas de aislamiento por workspace.
3. Login seguro y roles; la aprobación solo debe poder ejecutarla el propietario/administrador autenticado.
4. API backend de catálogo que entregue a los agentes exclusivamente precios aprobados.
5. Orquestador de IA con reglas del servidor: no inventar precios, no ofrecer descuentos, no enviar cotizaciones sin aprobación explícita.
6. Conectores oficiales y consentidos para WhatsApp Business/Meta, correo y formularios.
7. Pruebas de seguridad, recuperación, privacidad, auditoría y aceptación antes de publicar.

## Regla de producción para cada agente
`SELECT package_name, description, amount, currency, version FROM ic_price_catalog WHERE workspace_id = :workspace_id AND status = 'approved';`
No exponer registros pendientes ni permitir que el modelo complete importes faltantes. La autorización debe validarse en el servidor en el momento de generar y enviar cualquier oferta.

## Integración JEMITHA
Usar un proyecto/esquema aislado y tablas con prefijo `ic_`. No modificar tablas ni flujos existentes de JEMITHA CENTRAL, Pedido Fácil, Pintafácil o Movilidad.
